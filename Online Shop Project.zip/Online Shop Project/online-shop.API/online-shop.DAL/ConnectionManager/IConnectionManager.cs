﻿using System.Data;

namespace online_shop.DAL.ConnectionManager
{
    public interface IConnectionManager
    {
        IDbConnection DefaultConnection();
    }
}

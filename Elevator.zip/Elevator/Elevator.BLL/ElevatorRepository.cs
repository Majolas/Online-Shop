﻿using Elevator.BO;

namespace Elevator.BLL
{
    public class ElevatorRepository : IElevatorRepository
    {
        public int ElevatorNumber { get; set; }
        public int CurrentElevatorFloor { get;  set; }
        public Direction CurrentElevatorDirection { get;  set; }
        public bool IsElevatorMoving { get;  set; }

        public ElevatorRepository(int elevatorNumber)
        {
            ElevatorNumber = elevatorNumber;
            CurrentElevatorFloor = 1;
            CurrentElevatorDirection = Direction.Up;
            IsElevatorMoving = false;
        }

        public void ChangeFloor(int floor)
        {
            IsElevatorMoving = true;
            CurrentElevatorDirection = floor > CurrentElevatorFloor ? Direction.Up : Direction.Down;
            Console.WriteLine($"Elevator {ElevatorNumber} is moving {CurrentElevatorDirection.ToString().ToLower()} to floor {floor}...");

            while (CurrentElevatorFloor != floor)
            {
                if (CurrentElevatorDirection == Direction.Up)
                    CurrentElevatorFloor = CurrentElevatorFloor + 1;
                else
                    CurrentElevatorFloor = CurrentElevatorFloor - 1;

                Console.WriteLine($"Elevator {ElevatorNumber} is passing floor {CurrentElevatorFloor}...");
            }

            IsElevatorMoving = false;
            Console.WriteLine($"Elevator {ElevatorNumber} has arrived at floor {CurrentElevatorFloor}.");
        }
    }
}

﻿using Microsoft.Extensions.Configuration;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace online_shop.DAL.ConnectionManager
{
    public class ConnectionManager : IConnectionManager
    {
        private readonly IConfiguration _configuration;

        public ConnectionManager(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IDbConnection DefaultConnection()
        {
            return new SqlConnection(_configuration.GetConnectionString("OnlineShopDatabase"));
        }
    }
}

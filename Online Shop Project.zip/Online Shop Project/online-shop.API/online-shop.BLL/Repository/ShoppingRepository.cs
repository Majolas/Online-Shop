﻿using Dapper;
using online_shop.BO.Shop;
using online_shop.DAL.ConnectionManager;
using System.Data;
using System.Diagnostics;

namespace online_shop.BLL.Repository
{
    public class ShoppingRepository : IShoppingRepository
    {
        private readonly IConnectionManager _connectionManager;

        public ShoppingRepository(IConnectionManager connectionManager)
        {
            _connectionManager = connectionManager;
        }

        public async Task<IEnumerable<Product>> GetProducts()
        {
            using (IDbConnection db = _connectionManager.DefaultConnection())
            {
                return await db.QueryAsync<Product>("SELECT * FROM [dbo].[Product] ORDER BY [ProductId] ASC");
            }
        }

        public async Task<long> SaveOrder(Order order)
        {
            using (IDbConnection db = _connectionManager.DefaultConnection())
            {
                //Save order
                var insertOrderQuery = @"INSERT INTO [dbo].[Order](Price,OrderDate) VALUES (@Price, @OrderDate); SELECT CAST(SCOPE_IDENTITY() as int)";
                var result = await db.QueryAsync<int>(insertOrderQuery, new { @Price = order.Price, @OrderDate = DateTime.Now });

                if (result.Single() != 0)
                {
                    //Save orderItems
                    foreach (var item in order.OrderItems)
                    {
                        var insertOrderItemQuery = @"INSERT INTO [dbo].[OrderItem]([FK_OrderId],[Quantity],[Name],[Description],[Price]) VALUES (@OrderId, @Quantity, @Name, @Description, @Price)";
                        await db.QueryAsync<int>(insertOrderItemQuery, new { @OrderId = result.Single(), @Quantity = item.Quantity, @Name = item.Name, @Description = item.Description, @Price = item.Price});
                    }
                }
                return result.Single();
            }
        }

        public async Task<IEnumerable<Order>> GetOrders()
        {
            using (IDbConnection db = _connectionManager.DefaultConnection())
            {
                return await db.QueryAsync<Order>("SELECT * FROM [dbo].[Order]");
            }
        }

        public async Task<IEnumerable<OrderItem>> GetOrderItems(int OrderNumber)
        {
            using (IDbConnection db = _connectionManager.DefaultConnection())
            {
                return await db.QueryAsync<OrderItem>("SELECT * FROM [dbo].[OrderItem] WHERE [FK_OrderId] = @OrderNumber", new { OrderNumber = OrderNumber });
            }
        }
    }
}

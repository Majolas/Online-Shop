﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using online_shop.BLL.Repository;
using online_shop.BO.Shop;

namespace online_shop.API.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ShoppingController : ControllerBase
    {
        private readonly IShoppingRepository _shoppingRepository;

        public ShoppingController(ShoppingRepository shoppingRepository)
        {
            _shoppingRepository = shoppingRepository;
        }

        [HttpGet]
        [Route("GetProduct")]        
        [AllowAnonymous]
        public async Task<IEnumerable<Product>> GetProducts()
        {
            return await _shoppingRepository.GetProducts();
        }

        [HttpPost]
        [Route("SaveOrder")]
        [AllowAnonymous]
        public async Task<long> saveOrder(Order order)
        {
            return await _shoppingRepository.SaveOrder(order);
        }

        [HttpGet]
        [Route("OrderHistory")]
        [AllowAnonymous]
        public async Task<IEnumerable<Order>> GetOrders()
        {
            return await _shoppingRepository.GetOrders();
        }
        
        [HttpGet]
        [Route("OrderItemHistory")]
        [AllowAnonymous]
        public async Task<IEnumerable<OrderItem>> GetOrderItems(int orderNumber)
        {
            return await _shoppingRepository.GetOrderItems(orderNumber);
        }
    }
}

﻿namespace Elevator.BO
{
    public enum Direction
    {
        Up,
        Down
    }
}

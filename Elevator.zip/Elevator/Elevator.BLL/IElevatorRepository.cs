﻿namespace Elevator.BLL
{
    public interface IElevatorRepository
    {
       void ChangeFloor(int floor);
    }
}

﻿using Elevator.BLL;

namespace Elevator
{
    public class ElevatorController
    {
        private List<ElevatorRepository> listOfElevators;

        public ElevatorController(int numberOfElevators)
        {
            listOfElevators = new List<ElevatorRepository>();
            for (int i = 1; i <= numberOfElevators; i++)
            {
                listOfElevators.Add(new ElevatorRepository(i));
            }
        }

        public void RequestElevator(int floor)
        {
            ElevatorRepository closestElevator = null;
            int minimumDistance = int.MaxValue;

            foreach (var elevator in listOfElevators)
            {
                int distance = Math.Abs(elevator.CurrentElevatorFloor - floor);

                if (!elevator.IsElevatorMoving && distance < minimumDistance)
                {
                    closestElevator = elevator;
                    minimumDistance = distance;
                }
            }

            if (closestElevator != null)
            {
                closestElevator.ChangeFloor(floor);
            }
            else
            {
                Console.WriteLine("Please wait. All elevators are currently busy...");
            }
        }

        public void PrintElevatorStatus()
        {
            foreach (var elevator in listOfElevators)
            {
                string elevatorStatus = elevator.IsElevatorMoving ? $"Moving {elevator.CurrentElevatorDirection.ToString().ToLower()} to floor {elevator.CurrentElevatorFloor}" : $"Idle at floor {elevator.CurrentElevatorFloor}";
                Console.WriteLine($"Elevator {elevator.ElevatorNumber}: {elevatorStatus}");
            }
        }
    }
}

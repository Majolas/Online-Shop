﻿using online_shop.BO.Shop;

namespace online_shop.BLL.Repository
{
    public interface IShoppingRepository
    {
        Task<IEnumerable<Product>> GetProducts();
        Task<long> SaveOrder(Order order);
        Task<IEnumerable<Order>> GetOrders(); 
        Task<IEnumerable<OrderItem>> GetOrderItems(int OrderNumber);
    }
}

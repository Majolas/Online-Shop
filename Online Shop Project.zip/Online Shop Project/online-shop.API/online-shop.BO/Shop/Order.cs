﻿namespace online_shop.BO.Shop
{
    public class Order
    {
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public decimal Price { get; set; }
        public List<OrderItem> OrderItems { get; set; }
    }
}

﻿using Elevator;

public class Program
{
    public static void Main(string[] args)
    {
        // Create an elevator controller with 2 elevators
        var elevatorController = new ElevatorController(2);

        // Request the elevator to floor 5
        elevatorController.RequestElevator(5);

        // Move the elevator to floor 2
        elevatorController.RequestElevator(2);

        // Print the elevator status
        elevatorController.PrintElevatorStatus();

        Console.ReadLine();
    }
}

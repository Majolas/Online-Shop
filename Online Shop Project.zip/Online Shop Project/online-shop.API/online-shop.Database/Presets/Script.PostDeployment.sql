﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

INSERT INTO dbo.Product( [Name], [Description], [Price], [ImageUrl])
VALUES ('Milk','Milk',25,'https://cdn.shopify.com/s/files/1/0403/2203/9970/products/LLMDA_8_F_720x.png?v=1607522852'),
       ('Sugar','Sugar',30,'https://cdn.shopify.com/s/files/1/2795/1670/products/PhotoRoom_20210412_161912_800x.jpg?v=1618238062'),
	   ('Coffe','Coffe',35,'https://cdn.shopify.com/s/files/1/0593/3360/7590/products/Deluxe-Coffee-HouseBlend-New_1200x.jpg?v=1644319261'),
	   ('Cake','Cake',21,'https://assets.bonappetit.com/photos/57acadca1b3340441497511e/1:1/w_1600,c_limit/white-cupcakes.jpg'),
	   ('Bread','Bread',15,'https://m.media-amazon.com/images/I/71enZTEZeIL._SX679_.jpg')
	  
